This is a C# Visual Studio Library for Discord WebHooks.

usage example:

using Discord_WebHooks_Library;      <---- Import
using System;
using System.Linq;
using System.Text;

namespace WebHookTest
{
    class Program
    {
        static void Main(string[] args)
        {

            WebHooks.sendMessage("WEBHOOK LINK", "TEXT", "BOT NAME");   <---- Usage

        }
    }
}
